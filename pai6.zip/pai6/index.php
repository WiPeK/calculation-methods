<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Lab 6 xml</title>
	<link rel="stylesheet" href="css/style.css">
</head>
<body>
	<ul>
		<li>
			<a href="db/pacjenci.xml">
				Pacjenci [xml]
			</a>
		</li>
		<li>
			<a href="pacjenci.php">
				Pacjenci [php]
			</a>
		</li>
		<li>
			<a href="db/lekarze.xml">
				Lekarze [xml]
			</a>
		</li>
		<li>
			<a href="lekarze.php">
				Lekarze [php]
			</a>
		</li>
		<li>
			<a href="db/badania.xml">
				Badania [xml]
			</a>
		</li>
		<li>
			<a href="badania.php">
				Badania [php]
			</a>
		</li>
	</ul>
</body>
</html>