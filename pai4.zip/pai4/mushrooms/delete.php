<?php
	include("../config.php");
	$id_conn = mysql_connect($host, $user, $haslo);
	mysql_select_db($baza);
	if($id_conn == false) die( 'BŁĄD dostępu do danych!');
	if(isset($_GET["id"])) {
		$query = 'DELETE FROM mushrooms WHERE id="' . $_GET["id"] . '"';
		mysql_query($query);
		header("Location: mushrooms.php");
		exit();
	}
 ?>