<?php
	include("../config.php");
	$id_conn = mysql_connect($host, $user, $haslo);
	mysql_select_db($baza);
	if($id_conn == false) die( 'BŁĄD dostępu do danych!');
	if(isset($_GET["id"]) && !isset($_POST["submit"])) {
		$query = 'SELECT * FROM mushrooms WHERE id="' . $_GET["id"] . '"';
		$result = mysql_query($query);
		if($result == FALSE) echo 'BLĄD! Pobierania treści z
		bazy!';
		$mushroom = mysql_fetch_object($result);
	} else if(isset($_POST["submit"])) {
		if(isset($_GET["id"])) {
			$query = 'UPDATE mushrooms SET name="' . $_POST["name"] . '", amount="' . $_POST['amount'] . '" WHERE id="' . $_GET["id"] . '"';
		} else {
			$query = 'INSERT INTO mushrooms(id, name, amount) VALUES(NULL,"' . $_POST["name"] . '","' . $_POST["amount"] . '")';
		}
		mysql_query($query);
		header("Location: mushrooms.php");
		exit();
	} else {
		$mushroom = '';
	}
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="../css/style.css">
</head>
<body>
	<form class="login-form" action="<?php echo isset($_GET['id']) ? ('edit.php?id=' . $_GET['id']) : 'edit.php'; ?>" method="post" accept-charset="utf-8">
		Nazwa<input type="text" name="name" value="<?php echo isset($mushroom->name) ? $mushroom->name : ''; ?>">
		Ilość<input type="number" name="amount" value="<?php echo isset($mushroom->amount) ? $mushroom->amount : ''; ?>">
		<input type="submit" name="submit" value="Zapisz">
	</form>
</body>
</html>