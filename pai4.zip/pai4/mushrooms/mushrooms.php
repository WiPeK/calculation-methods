<?php
	include("../config.php");
	$id_conn = mysql_connect($host, $user, $haslo);
	mysql_select_db($baza);
	if($id_conn == false) die( 'BŁĄD dostępu do danych!');

	if(isset($_GET["sort"])) {
		$query = 'SELECT * FROM mushrooms ORDER BY ' . $_GET["sort"] . ' ASC';
	} else {
		$query = 'SELECT * FROM mushrooms';
	}

	$result = mysql_query($query);
	if($result == FALSE) echo 'BLĄD! Pobierania treści z
	bazy!';
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Atlas grzybów</title>
	<link rel="stylesheet" href="../css/style.css">
</head>
<body>
	<p>
		<a href="edit.php">Dodaj</a>
	</p>
	<p>Sortowanie
		<form action="mushrooms.php" method="get">
			<select name="sort" multiple>
				<option value="id">Id</option>
				<option value="name">Nazwa</option>
				<option value="amount">Ilosc</option>
			</select>
			<input type="submit" name="submit" value="Sortuj">
		</form>
	</p>
	<table>
		<caption>Atlas grzybów</caption>
		<thead>
			<tr>
				<th>Nazwa</th>
				<th>Ilość</th>
				<th>Edytuj</th>
				<th>Usuń</th>
			</tr>
		</thead>
		<tbody>
			<?php while ($row = mysql_fetch_assoc($result)): ?>
            <tr>
				<td><?php echo $row["name"] ?></td>
				<td><?php echo $row["amount"] ?></td>
				<td><a href="edit.php?id=<?php echo $row["id"]; ?>">Edytuj</a></td>
				<td><a href="delete.php?id=<?php echo $row["id"]; ?>">Usuń</a></td>
			</tr>
			<?php endwhile; ?>
		</tbody>
	</table>
</body>
</html>