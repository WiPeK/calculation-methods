<?php
	session_start();
	if (isset($_SESSION) && isset($_SESSION["isLogged"])) {
		echo $_SESSION["login"] . ' jestes juz zalogowany/a';
		echo '<a href="logout.php">Wyloguj</a>';
		die();
	}
 ?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="css/style.css">
</head>
<body>
	<form class="login-form" action="login.php" method="post" accept-charset="utf-8">
		<input type="text" name="login" value="12345678">
		<input type="password" name="password" value="12345678">
		<input type="submit" name="submit" value="Login">
	</form>
</body>
</html>