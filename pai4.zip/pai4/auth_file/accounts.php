<?php
	if (isset($_POST["submit"])) {
		$row = htmlspecialchars($_POST["login"]) . "|" . md5(htmlspecialchars($_POST["password"]));
		$file = fopen("accounts.txt", "a");
		//fputs($file, $row);
		file_put_contents("accounts.txt", $row . "\r\n", FILE_APPEND);
		fclose($file);
		header("Location: list.php");
		exit();
	}
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Dodaj konto</title>
	<link rel="stylesheet" href="../css/style.css">
</head>
<body>
	<form class="login-form" method="post" action="accounts.php">
		Login <input type="text" name="login" required>
		Hasło <input type="password" name="password" required>
		<input type="submit" name="submit" value="Dodaj">
	</form>
</body>
</html>