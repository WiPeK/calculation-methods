<?php
	$status = FALSE;
	if (isset($_POST["submit"])) {
		$login = htmlspecialchars($_POST["login"]);
		$password = md5(htmlspecialchars($_POST["password"]));

		$row = $login . "|" . $password;

		$file = fopen("accounts.txt", "r");
		$rows = file("accounts.txt");

		for($x = 0; $x < count($rows); $x++) {
			if ($rows[$x] == $row) {
				$status = TRUE;
				break;
			}
		}
		fclose($file);
	}
 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<meta charset="utf-8">
 	<meta http-equiv="X-UA-Compatible" content="IE=edge">
 	<title>Status logowania</title>
 	<link rel=stylesheet href="../css/style.css">
 </head>
 <body>
 	<?php if ($status): ?>
		<h1 class="success">Zalogowano</h1>
 	<?php else: ?>
		<h4 class="error">Nie mozna zalogowac</h4>
 	<?php endif; ?>
 </body>
 </html>