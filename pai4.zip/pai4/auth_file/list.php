<?php
	$file = fopen("accounts.txt", "r");
	$rows = file("accounts.txt");
	fclose($file);
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Lista kont</title>
	<link rel="stylesheet" href="../css/style.css">
</head>
<body>
<a href="accounts.php">Dodaj konto</a>
	<table>
		<caption>Lista kont</caption>
		<thead>
			<tr>
				<th>Login</th>
			</tr>
		</thead>
		<tbody>
		<?php for($x = 0; $x < count($rows); $x++): ?>
			<?php $t = explode("|", $rows[$x]); ?>
		<tr>
			<td><?php echo $t[0]; ?></td>
		</tr>
		<?php endfor; ?>
		</tbody>
	</table>
</body>
</html>