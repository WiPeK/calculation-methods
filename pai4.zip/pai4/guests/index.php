<?php
	$file = fopen("guests.txt", "r");
	$rows = file("guests.txt");
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Ksiega gosci</title>
	<link rel="stylesheet" href="../css/style.css">
</head>
<body>
	<a href="add.php">Wpisz sie na liste</a>

	<table>
		<caption>Ksiega gosci</caption>
		<thead>
			<tr>
				<th>Imie</th>
				<th>Nazwisko</th>
				<th>Opis</th>
			</tr>
		</thead>
		<tbody>
		<?php for($x = 0; $x < count($rows); $x++): ?>
			<?php $t = explode("|", $rows[$x]); ?>
		<tr>
			<?php for($y = 0; $y < count($t); $y++): ?>
				<td><?php echo $t[$y]; ?></td>
			<?php endfor; ?>
		</tr>
		<?php endfor; ?>
		</tbody>
	</table>
</body>
</html>