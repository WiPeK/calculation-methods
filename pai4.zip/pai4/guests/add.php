<?php
	if (isset($_POST["submit"])) {
		$row = $_POST["namesurname"] . "|" . $_POST["address"] . "|" . $_POST["content"] . '\n';
		$file = fopen("guests.txt", "a");
		//fputs($file, $row);
		file_put_contents("guests.txt", $row . "\r\n", FILE_APPEND);
		fclose($file);
		header("Location: index.php");
		exit();
	}
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Dodaj wpis</title>
	<link rel="stylesheet" href="../css/style.css">
</head>
<body>
	<form class="login-form" method="post" action="add.php">
		Imie i nazwisko <input type="text" name="namesurname" required>
		Adres <input type="text" name="address" required>
		Opis <input type="text" name="content" required>
		<input type="submit" name="submit" value="Dodaj">
	</form>
</body>
</html>