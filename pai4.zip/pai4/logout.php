<?php
	session_start();
	unset($_SESSION["isLogged"]);
	unset($_SESSION["login"]);
	unset($_SESSION);
	header("Location: index.php");
	exit();
?>