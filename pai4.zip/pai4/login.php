<?php
	session_start();
	if (isset($_POST["submit"]) && !isset($_SESSION["isLogged"])) {
		$login = htmlspecialchars($_POST["login"]);
		$password = md5(htmlspecialchars($_POST["password"]));

		include("config.php");

		$id_conn = mysql_connect($host, $user, $haslo);
		mysql_select_db($baza);
		if($id_conn == false) die( 'BŁĄD dostępu do danych!');

		$query = 'SELECT * FROM users where login="' . $login . '" AND password="' . $password . '"';

		$result = mysql_query($query);
		if($result == FALSE) echo 'BLĄD! Pobierania treści z
		bazy!';
		$userFromDb = mysql_fetch_object($result);
		if ($userFromDb != NULL) {
			$_SESSION["isLogged"] = TRUE;
			$_SESSION["login"] = $userFromDb->login;
		}
	}
 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<meta charset="utf-8">
 	<meta http-equiv="X-UA-Compatible" content="IE=edge">
 	<title>Status logowania</title>
 	<link rel=stylesheet href="css/style.css">
 </head>
 <body>
 	<?php if ($_SESSION["isLogged"]): ?>
		<h1 class="success">Zalogowano</h1>
		<a href="logout.php">Wyloguj</a>
 	<?php else: ?>
		<h4 class="error">Nie mozna zalogowac</h4>
 	<?php endif; ?>
 </body>
 </html>