<?php
	if (isset($_COOKIE["last_visit"])) {
		$last_visited_time = time() - $_COOKIE["last_visit"];
	}
	setcookie('test_expired', time(), time() + (60), "/");
	if (!isset($_COOKIE["test_expired"]))
	setcookie('last_visit', time(), time() + (86400 * 30), "/");
 ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Ciasteczka</title>
	<link rel="stylesheet" href="">
</head>
<body>
	<p>Ostatnio odwiedzono strone: <?php echo isset($last_visited_time) ? $last_visited_time : 0; ?> temu</p>
	<?php if(isset($_COOKIE["test_expired"])): ?>
		<p>Ciasteczko wygaśnie za <?php echo time() - $_COOKIE["test_expired"]; ?></p>
	<?php else: ?>
		<p>Ciasteczko wygasło</p>
	<?php endif; ?>
</body>
</html>