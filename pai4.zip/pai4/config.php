<?php
	$user = 'root';
	$haslo ='root';
	$host = 'localhost';
	$baza = 'pai';
?>